<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <footer class="py-4 bg-light mt-auto">
            <div class="container-fluid px-4">
                <div class="d-flex align-items-center justify-content-between small">
                    <div class="text-muted">Copyright &copy;<script>document.write(new Date().getFullYear())</script> <a href="#"><b>Nhóm 1</b></a> </div>
                    <div>
                        <p><i>phiên bản 1.0</i></p>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>
