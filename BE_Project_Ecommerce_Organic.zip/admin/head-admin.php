<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $title ?></title>
<link rel="shortcut icon" href="../public/images/icon/admin.png" type="image/x-icon">
<link rel="stylesheet" href="../public/bootstrap-5/css/bootstrap.min.css">
<link href="../public/css/styles.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"
crossorigin="anonymous"></script>
<script src="../public/ckeditor/ckeditor.js"></script>