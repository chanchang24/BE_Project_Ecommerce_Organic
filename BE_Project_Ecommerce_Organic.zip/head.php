<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo $title ?></title>
<link rel="shortcut icon" href="./public/img/logo.png" type="image/x-icon">
<!-- Css Styles -->
<link rel="stylesheet" href="public/css/bootstrap.min.css" type="text/css">
<link rel="stylesheet" href="public/css/font-awesome.min.css" type="text/css">
<link rel="stylesheet" href="public/css/elegant-icons.css" type="text/css">
<link rel="stylesheet" href="public/css/nice-select.css" type="text/css">
<link rel="stylesheet" href="public/css/jquery-ui.min.css" type="text/css">
<link rel="stylesheet" href="public/css/owl.carousel.min.css" type="text/css">
<link rel="stylesheet" href="public/css/slicknav.min.css" type="text/css">
<link rel="stylesheet" href="public/css/style.css" type="text/css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/locale/vi.min.js" integrity="sha512-LvYVj/X6QpABcaqJBqgfOkSjuXv81bLz+rpz0BQoEbamtLkUF2xhPNwtI/xrokAuaNEQAMMA1/YhbeykYzNKWg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
