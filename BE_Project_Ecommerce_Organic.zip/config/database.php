<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'id18259860_group1be2021');
define('DB_PASS', '2Vx<Yda~>P6MfbSI');
define('DB_NAME', 'id18259860_group1_be_2021');

?>
    